package net.androidly.androidlylistview

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var colorArrays = resources.getStringArray(R.array.Colors)
        var arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, colorArrays)

        listView.adapter = arrayAdapter

        listView.setOnItemClickListener { adapterView, view, position: Int, id: Long ->


            toast(colorArrays[position])
        }
    }
}
